#!/bin/bash
export PATH="/google/idx/builtins/bin:$PATH"
cd /home/user/studio/cozinha-afeto-e039fb5a-main
exec npm run dev