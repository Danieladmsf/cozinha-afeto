import Customers from '@/components/clientes/Customers';

export default function CustomersPage() {
  return <Customers />;
}