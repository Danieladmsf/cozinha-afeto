'use client';

import React from 'react';
import CustomerPortal from '@/components/clientes/CustomerPortal';

export default function CustomerPortalClient() {
  return <CustomerPortal />;
}