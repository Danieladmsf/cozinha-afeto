
'use client';

import MenuSettingsComponent from '@/components/configurar-cardapio/MenuSettingsComponent';

export default function MenuSettings() {
  return <MenuSettingsComponent />;
}