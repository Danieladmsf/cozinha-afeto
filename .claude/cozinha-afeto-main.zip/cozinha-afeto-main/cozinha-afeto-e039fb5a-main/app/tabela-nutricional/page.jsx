import Nutrition from '@/components/tabela-nutricional/Nutrition';

export default function NutritionPage() {
  return <Nutrition />;
}