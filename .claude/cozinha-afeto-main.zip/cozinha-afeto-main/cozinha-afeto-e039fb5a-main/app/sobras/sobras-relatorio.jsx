'use client';

import React from "react";
import SobrasRelatorioComponent from '@/components/sobras/relatorio/SobrasRelatorioComponent';

export default function SobrasRelatorio() {
  return <SobrasRelatorioComponent />;
}