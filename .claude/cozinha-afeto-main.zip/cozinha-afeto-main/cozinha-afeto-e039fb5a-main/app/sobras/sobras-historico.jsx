'use client';

import React from "react";
import SobrasHistoricoComponent from '@/components/sobras/historico/SobrasHistoricoComponent';

export default function SobrasHistorico() {
  return <SobrasHistoricoComponent />;
}