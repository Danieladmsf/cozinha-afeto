'use client';

import React from "react";
import SobrasRegistroComponent from '@/components/sobras/registro/SobrasRegistroComponent';

export default function SobrasRegistro() {
  return <SobrasRegistroComponent />;
}