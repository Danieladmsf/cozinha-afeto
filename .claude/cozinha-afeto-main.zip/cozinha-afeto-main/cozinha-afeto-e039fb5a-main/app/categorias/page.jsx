import Categories from '@/components/categorias/Categories';

export default function CategoriesPage() {
  return <Categories />;
}