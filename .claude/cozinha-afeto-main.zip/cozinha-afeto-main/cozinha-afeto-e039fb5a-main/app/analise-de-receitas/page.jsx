import RecipeAnalysis from '@/components/analise-de-receitas/RecipeAnalysis';

export default function RecipeAnalysisPage() {
  return <RecipeAnalysis />;
}