import Orders from '@/components/pedidos/Orders';

export default function OrdersPage() {
  return <Orders />;
}