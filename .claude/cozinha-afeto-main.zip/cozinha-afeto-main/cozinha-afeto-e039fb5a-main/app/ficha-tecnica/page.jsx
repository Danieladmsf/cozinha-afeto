import RecipeTechnical from '@/components/ficha-tecnica/RecipeTechnical';

export default function RecipeTechnicalPage() {
  return <RecipeTechnical />;
}