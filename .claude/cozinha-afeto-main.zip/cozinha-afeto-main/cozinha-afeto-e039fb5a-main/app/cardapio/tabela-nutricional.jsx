'use client';

import React from "react";
import NutritionalTableComponent from '@/components/cardapio/nutricional/NutritionalTableComponent';

export default function TabelaNutricional() {
  return <NutritionalTableComponent />;
}