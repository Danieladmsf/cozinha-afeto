'use client';

import React from "react";
import ClientMenuComponent from '@/components/cardapio/cliente/ClientMenuComponent';

export default function CardapioCliente() {
  return <ClientMenuComponent />;
}