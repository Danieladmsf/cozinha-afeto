'use client';

import React from "react";
import WeeklyMenuComponent from '@/components/cardapio/semanal/WeeklyMenuComponent';

export default function CardapioSemanal() {
  return <WeeklyMenuComponent />;
}