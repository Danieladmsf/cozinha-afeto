import Ingredients from '@/components/ingredientes/Ingredients';

export default function IngredientsPage() {
  return <Ingredients />;
}