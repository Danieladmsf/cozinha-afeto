import IngredientEditor from '@/components/ingredientes/IngredientEditor';

export default function IngredientEditorPage() {
  return <IngredientEditor />;
}