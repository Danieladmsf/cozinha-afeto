import BillManagement from '@/components/contas/BillManagement';

export default function BillManagementPage() {
  return <BillManagement />;
}