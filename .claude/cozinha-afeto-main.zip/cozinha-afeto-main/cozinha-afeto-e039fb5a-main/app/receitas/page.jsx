import Recipes from '@/components/receitas/Recipes';

export default function RecipesPage() {
  return <Recipes />;
}