import Suppliers from '@/components/fornecedores-e-servicos/Suppliers';

export default function SuppliersPage() {
  return <Suppliers />;
}