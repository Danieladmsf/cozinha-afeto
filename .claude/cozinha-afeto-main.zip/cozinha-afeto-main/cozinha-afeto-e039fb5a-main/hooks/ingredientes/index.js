// Hooks específicos para o módulo Ingredientes
// Adicionar hooks futuros aqui
// export { useIngredientOperations } from './useIngredientOperations';
// export { useNutritionCalculator } from './useNutritionCalculator';