// Hooks específicos para o módulo Pedidos
// Adicionar hooks futuros aqui
// export { useOrderOperations } from './useOrderOperations';
// export { useOrderCalculations } from './useOrderCalculations';