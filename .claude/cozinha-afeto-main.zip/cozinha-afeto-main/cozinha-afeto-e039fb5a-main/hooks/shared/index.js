// Hooks compartilhados entre módulos
export { generateWeekKey, getWeekStartDate, getWeekInfo } from './weekUtils';
// export { useApiClient } from './useApiClient';
// export { useFormValidation } from './useFormValidation';
// export { useLocalStorage } from './useLocalStorage';