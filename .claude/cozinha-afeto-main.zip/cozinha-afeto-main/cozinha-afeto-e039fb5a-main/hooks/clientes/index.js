// Hooks para módulo de clientes
export { useCustomerLink } from './useCustomerLink';